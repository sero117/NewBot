#!/bin/bash
pip install -r requirements.txt
python3 El_Minshawi_Bot.py
